# Arcane Beam Resource Pack Sound Slots

Replace these placeholder .ogg files with real Ogg Vorbis sound files, keeping the exact names and paths.

Arcane slots loop while Arcane is active:
- assets/arcanebeam/sounds/abilities/arcane_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/arcane_resourcepack_2.ogg

Rail slots play once per Rail cast:
- assets/arcanebeam/sounds/abilities/rail_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/rail_resourcepack_2.ogg

Lightning Strike Resourcepack1 slots:
- assets/arcanebeam/sounds/abilities/lightning_resourcepack_1_cast.ogg
- assets/arcanebeam/sounds/abilities/lightning_resourcepack_1_impact.ogg

Lightning Strike Resourcepack2 slots:
- assets/arcanebeam/sounds/abilities/lightning_resourcepack_2_cast.ogg
- assets/arcanebeam/sounds/abilities/lightning_resourcepack_2_impact.ogg

Vault Altar slots play once when the altar beam replacement starts:
- assets/arcanebeam/sounds/abilities/vault_altar_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/vault_altar_resourcepack_2.ogg

Storm Arrow strike slots play when a Storm Arrow strike hits a valid target:
- assets/arcanebeam/sounds/abilities/storm_arrow_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/storm_arrow_resourcepack_2.ogg

Storm Arrow projectile slots play when the target designator projectile is fired:
- assets/arcanebeam/sounds/abilities/storm_arrow_projectile_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/storm_arrow_projectile_resourcepack_2.ogg

Smite strike slots play when a Smite bolt hits a valid target:
- assets/arcanebeam/sounds/abilities/smite_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/smite_resourcepack_2.ogg

Smite activation slots play when Smite activates:
- assets/arcanebeam/sounds/abilities/smite_activation_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/smite_activation_resourcepack_2.ogg

Archon strike slots play when an Archon bolt hits a valid target:
- assets/arcanebeam/sounds/abilities/archon_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/archon_resourcepack_2.ogg

Archon activation slots play when Archon activates:
- assets/arcanebeam/sounds/abilities/archon_activation_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/archon_activation_resourcepack_2.ogg

Lightning Strike cast sounds are Seismic Charge shot slots. Lightning Strike impact sounds play when Lightning Strike detonates on a valid target.

No sounds.json is needed for these Arcane Beam slots. Enable this resource pack, then choose Resourcepack1 or Resourcepack2 in the Arcane, Rail, Lightning Strike, Vault Altar, Storm Arrow, Smite, or Archon sound setting.

## Remote Player Beam Profile Example

This pack also contains an example remote-player beam profile:

- assets/arcanebeam_examples/arcanebeam/beam_profiles/blue_arcane.json

Its profile id is `arcanebeam_examples:blue_arcane`. Assign it in:

- config/arcanebeam/player_beams/assignments.json

Example:

```json
{
  "players": [
    {
      "uuid": "00000000-0000-0000-0000-000000000000",
      "name": "PlayerName",
      "profile": "arcanebeam_examples:blue_arcane"
    }
  ]
}
```

UUID matching takes priority. Unassigned players and particles with ambiguous ownership retain Vault's default particle beam. Press F3+T after editing assignments or profile JSON.

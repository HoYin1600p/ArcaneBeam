# Arcane Beam Resource Pack Sound Slots

Replace these placeholder .ogg files with real Ogg Vorbis sound files, keeping the exact names and paths.

Arcane slots loop while Arcane is active:
- assets/arcanebeam/sounds/abilities/arcane_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/arcane_resourcepack_2.ogg

Rail slots play once per Rail cast:
- assets/arcanebeam/sounds/abilities/rail_resourcepack_1.ogg
- assets/arcanebeam/sounds/abilities/rail_resourcepack_2.ogg

No sounds.json is needed for these Arcane Beam slots. Enable this resource pack, then choose Resourcepack1 or Resourcepack2 in the Arcane/Rail sound setting.
